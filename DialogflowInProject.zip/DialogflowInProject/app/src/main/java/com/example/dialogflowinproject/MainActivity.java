package com.example.dialogflowinproject;
import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.content.Intent;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

/**
 * Description of the Activity
 * The MainActivity is handling the chatbot session, including
 * fields that allow for the user to send text and see the response
 * in a viewed manner
 */
public class MainActivity extends AppCompatActivity {

    //fields for chatbot

    /*private field userInputEditText allows for the user to type
     * their question to the chatbot*/
    private EditText userInputEditText;
    /*private field chatDisplayTextView is a TextView that adds the user input
     * and chatbot input simultaneously*/
    private TextView chatDisplayTextView;

    /*private field chatScroll goes to the bottom of the chat, and allows the user to
     * move the chat up and down*/
    private ScrollView chatScroll;

    /*private field bot is an instance of HandleChatBot that allows for
     * the session to be created*/
    private HandleChatBot bot;


    /*private field uniqueId is the unique id for each user*/
    private String uniqueId;
    /*private field redo is an Intent that is detected by the chatbot if it is opened from navigation*/

    /**
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     * the onCreate method is used to reinitialize the activity and is the main space where private fields
     * get initialized and remade.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*this createsa uniqueId each time a session is made*/
        uniqueId = UUID.randomUUID().toString();


        /*allows for Dialogflow connection to start*/
        initializeDialogflow();

        userInputEditText = findViewById(R.id.userInputEditText);
        chatDisplayTextView = findViewById(R.id.chatDisplayTextView);
        Button sendButton = findViewById(R.id.sendButton);
        chatScroll = findViewById(R.id.chatScrollView);



        // Initialize Dialogflow


        // Send user input to Dialogflow when the button is clicked
        sendButton.setOnClickListener(view -> {
            chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_UP));
            String userInput = userInputEditText.getText().toString().trim();
            userInputEditText.setText(""); // Clear input field

            if (!userInput.isEmpty()) {
                displayUserMessage(userInput);
                sendUserInputToDialogflow(userInput);
            }
        });

    }





    /**
     * method initializeDialogflow allows the connection and the inputstream to be connected
     * to the chatbot
     */

    private void initializeDialogflow() {
        try {
            // Load the credentials JSON file from the raw resource folder
            uniqueId = UUID.randomUUID().toString();
            /*
            Replace credentials with name of the json file
             */
            InputStream stream = getResources().openRawResource(R.raw.credentials);
            /*
            Replace project_id with project id of your agent - check res/values/strings.xml
             */
            bot = new HandleChatBot(stream, getString(R.string.project_id),uniqueId);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * the method sendUserInputtoDialogflow sends whatever the user says to the agent, and shows the message
     * @param userInput is the input that the user supplies
     */

    private void sendUserInputToDialogflow(String userInput) {

        //debugging
        if (bot == null) {
            displayChatMessage("Dialogflow session is not initialized.");
            return;
        }
        displayChatMessage(bot.getResponse(userInput));

        // Create a text input

    }

    /**
     * method displayChatMessage will display the response of the chatbot
     * @param message is the respones of the chatbot
     */

    private void displayChatMessage(String message) {
        chatDisplayTextView.append("ChatGenius: " + message + "\n");
        chatDisplayTextView.append("\n");
        scrollToBottomChat();
    }

    /**
     * method displayUserMessage adds the user's message to the chat display
     * @param message is the question of the user to the chatbot
     */
    private void displayUserMessage(String message){
        chatDisplayTextView.append("You: " + message + "\n");
        chatDisplayTextView.append("\n");
        scrollToBottomChat();

    }

    /*the method scrollToBottomChat moves the chat to the bottom*/
    private void scrollToBottomChat() {
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }



}
