package com.example.dialogflowinproject;

import android.util.Log;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.dialogflow.v2.DetectIntentRequest;
import com.google.cloud.dialogflow.v2.DetectIntentResponse;
import com.google.cloud.dialogflow.v2.QueryInput;
import com.google.cloud.dialogflow.v2.SessionName;
import com.google.cloud.dialogflow.v2.SessionsClient;
import com.google.cloud.dialogflow.v2.SessionsSettings;
import com.google.cloud.dialogflow.v2.TextInput;

import java.io.InputStream;
import java.util.UUID;

/**
 * Description of HandleChatBot
 * This class is meant to handle the code of creating the Chatbot in
 * the program, to initiate the connection through Dialagflow
 */
public class HandleChatBot {
    /*private field sessionsClient allows for the independent client interaction to start*/
    private SessionsClient sessionsClient;
    /*private field session allows for the individual session to take placed*/
    private SessionName session;

    /**
     * This constructor creates a new HandleChatBot object that allows for the session to be created. The credentials
     * allow for the internet connectivity to be established, and for the session to happen
     * @param stream is the InputStream required to create the connection
     * @param projectId is the id of the project that comes from the json file to be able to connect to the correct
     * Dialogflow Agent
     * @param sessionId is the specific id for each session of the chat
     */
    public HandleChatBot(InputStream stream, String projectId, String sessionId){
        try{
            GoogleCredentials credentials = GoogleCredentials.fromStream(stream);
            SessionsSettings.Builder settingsBuilder = SessionsSettings.newBuilder();
            SessionsSettings sessionsSettings = settingsBuilder.setCredentialsProvider(() -> credentials).build();
            sessionsClient = SessionsClient.create(sessionsSettings);


            session = SessionName.of(projectId, sessionId);


        }
        catch(Exception e){
            e.printStackTrace();
        }

    }

    /**
     * The getResponse method takes whatever the user says and will create a response depending
     * on the intents coded into the Dialogflow Agent
     * @param userInput is whatever the user asks the agent. It gets the response through the sessionsClient
     * @return the response of the Dialogflow Agent in string form if there is a response
     */
    public String getResponse(String userInput){
        if (session == null || sessionsClient == null)
            return null;

        // Create a text input
        TextInput.Builder textInput = TextInput.newBuilder().setText(userInput).setLanguageCode("en-US");

        // Create a query input
        QueryInput queryInput = QueryInput.newBuilder().setText(textInput).build();

        // Send a request to Dialogflow
        try {
            DetectIntentResponse response = sessionsClient.detectIntent(DetectIntentRequest.newBuilder()
                    .setSession(session.toString())
                    .setQueryInput(queryInput)
                    .build());

            // Handle the response
            return response.getQueryResult().getFulfillmentText();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
}
